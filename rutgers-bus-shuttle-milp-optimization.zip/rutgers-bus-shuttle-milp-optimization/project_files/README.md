# Original Project Files

This folder contains the original Excel Solver workbook used to validate the Python implementation.

The large PowerPoint presentation is summarized in `docs/project_presentation_summary.md` so the GitHub repository remains lightweight.
