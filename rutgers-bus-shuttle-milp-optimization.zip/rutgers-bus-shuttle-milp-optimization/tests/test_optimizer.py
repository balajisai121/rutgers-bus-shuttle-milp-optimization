from __future__ import annotations

import json
import unittest
from pathlib import Path

from src.optimizer import load_routes, solve_bus_network

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "config" / "model_config.json").read_text(encoding="utf-8"))


class TestRutgersBusMILP(unittest.TestCase):
    def solve_period(self, period: str):
        period_config = CONFIG["periods"][period]
        routes = load_routes(ROOT / period_config["data_file"])
        return solve_bus_network(
            routes=routes,
            required_stops=period_config["required_stops"],
            bus_cost_weight=CONFIG["bus_cost_weight"],
            max_buses_per_route=CONFIG["max_buses_per_route"],
        )

    def test_weekday_reproduces_excel_solver(self):
        solution = self.solve_period("weekday")
        self.assertTrue(solution.success)
        self.assertEqual(set(solution.selected_routes), {"EE", "F", "H", "LX"})
        self.assertEqual(solution.total_buses, 4)
        self.assertAlmostEqual(solution.passenger_time_component, 170.0)
        self.assertAlmostEqual(solution.bus_cost_component, 2000.0)
        self.assertAlmostEqual(solution.objective_value, 2170.0)

    def test_weekend_reproduces_excel_solver(self):
        solution = self.solve_period("weekend")
        self.assertTrue(solution.success)
        self.assertEqual(solution.selected_routes, ["Weekend 1"])
        self.assertEqual(solution.total_buses, 1)
        self.assertAlmostEqual(solution.objective_value, 564.0)

    def test_all_required_stops_are_covered(self):
        for period in ("weekday", "weekend"):
            solution = self.solve_period(period)
            self.assertTrue(all(value >= 1 for value in solution.stop_coverage.values()))

    def test_inactive_routes_receive_no_buses(self):
        solution = self.solve_period("weekday")
        for route, active in solution.route_activation.items():
            if active == 0:
                self.assertEqual(solution.bus_allocation[route], 0)


if __name__ == "__main__":
    unittest.main()
