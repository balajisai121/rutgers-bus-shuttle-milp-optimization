from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt

from src.optimizer import OptimizationSolution, load_routes, solve_bus_network

ROOT = Path(__file__).resolve().parent


def write_solution(period: str, solution: OptimizationSolution, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    with (output_dir / f"{period}_solution.csv").open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["route", "active", "buses"])
        for route in solution.route_activation:
            writer.writerow(
                [route, solution.route_activation[route], solution.bus_allocation[route]]
            )

    with (output_dir / f"{period}_stop_coverage.csv").open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["stop", "number_of_active_routes_covering_stop"])
        writer.writerows(solution.stop_coverage.items())

    summary = {
        "period": period,
        "success": solution.success,
        "status": solution.status,
        "selected_routes": solution.selected_routes,
        "total_buses": solution.total_buses,
        "passenger_time_component": solution.passenger_time_component,
        "bus_cost_component": solution.bus_cost_component,
        "objective_value": solution.objective_value,
    }
    (output_dir / f"{period}_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )


def plot_solution(period: str, solution: OptimizationSolution, assets_dir: Path) -> None:
    assets_dir.mkdir(parents=True, exist_ok=True)
    routes = list(solution.bus_allocation)
    buses = [solution.bus_allocation[r] for r in routes]

    plt.figure(figsize=(9, 4.8))
    plt.bar(routes, buses)
    plt.title(f"{period.title()} Optimal Bus Allocation")
    plt.xlabel("Route")
    plt.ylabel("Number of buses")
    plt.ylim(0, max(2, max(buses, default=0) + 1))
    plt.tight_layout()
    plt.savefig(assets_dir / f"{period}_bus_allocation.png", dpi=180)
    plt.close()


def run_sensitivity(config: dict, output_dir: Path, assets_dir: Path) -> None:
    period = "weekday"
    period_config = config["periods"][period]
    routes = load_routes(ROOT / period_config["data_file"])
    costs = [0, 100, 250, 500, 750, 1000]
    records: list[dict] = []

    for cost in costs:
        solution = solve_bus_network(
            routes=routes,
            required_stops=period_config["required_stops"],
            bus_cost_weight=cost,
            max_buses_per_route=config["max_buses_per_route"],
        )
        records.append(
            {
                "bus_cost_weight": cost,
                "objective_value": solution.objective_value,
                "passenger_time_component": solution.passenger_time_component,
                "bus_cost_component": solution.bus_cost_component,
                "total_buses": solution.total_buses,
                "selected_routes": "; ".join(solution.selected_routes),
            }
        )

    with (output_dir / "weekday_bus_cost_sensitivity.csv").open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.DictWriter(file, fieldnames=records[0].keys())
        writer.writeheader()
        writer.writerows(records)

    plt.figure(figsize=(8.5, 4.8))
    plt.plot(costs, [r["objective_value"] for r in records], marker="o", label="Total objective")
    plt.plot(costs, [r["passenger_time_component"] for r in records], marker="o", label="Passenger-time component")
    plt.plot(costs, [r["bus_cost_component"] for r in records], marker="o", label="Bus-cost component")
    plt.title("Weekday Sensitivity to the Bus-Cost Weight")
    plt.xlabel("Bus-cost weight (c)")
    plt.ylabel("Objective contribution")
    plt.legend()
    plt.tight_layout()
    plt.savefig(assets_dir / "weekday_bus_cost_sensitivity.png", dpi=180)
    plt.close()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Solve the Rutgers bus route-selection MILP."
    )
    parser.add_argument(
        "--period",
        choices=["weekday", "weekend", "all"],
        default="all",
        help="Model period to solve (default: all).",
    )
    parser.add_argument(
        "--bus-cost",
        type=float,
        default=None,
        help="Override the bus-cost weight in the configuration.",
    )
    parser.add_argument(
        "--plots",
        action="store_true",
        help="Generate PNG plots in the assets directory.",
    )
    parser.add_argument(
        "--sensitivity",
        action="store_true",
        help="Run the predefined weekday bus-cost sensitivity analysis.",
    )
    args = parser.parse_args()

    config = json.loads((ROOT / "config" / "model_config.json").read_text(encoding="utf-8"))
    periods = list(config["periods"]) if args.period == "all" else [args.period]
    bus_cost = config["bus_cost_weight"] if args.bus_cost is None else args.bus_cost

    for period in periods:
        period_config = config["periods"][period]
        routes = load_routes(ROOT / period_config["data_file"])
        solution = solve_bus_network(
            routes=routes,
            required_stops=period_config["required_stops"],
            bus_cost_weight=bus_cost,
            max_buses_per_route=config["max_buses_per_route"],
        )
        if not solution.success:
            raise SystemExit(f"{period.title()} model failed: {solution.status}")

        write_solution(period, solution, ROOT / "results")
        if args.plots:
            plot_solution(period, solution, ROOT / "assets")

        print(f"\n{period.title()} solution")
        print("-" * (len(period) + 9))
        print(f"Selected routes: {', '.join(solution.selected_routes)}")
        print(f"Total buses: {solution.total_buses}")
        print(f"Passenger-time component: {solution.passenger_time_component:.0f}")
        print(f"Bus-cost component: {solution.bus_cost_component:.0f}")
        print(f"Objective value: {solution.objective_value:.0f}")

    if args.sensitivity:
        run_sensitivity(config, ROOT / "results", ROOT / "assets")
        print("\nSensitivity results written to results/ and assets/.")


if __name__ == "__main__":
    main()
