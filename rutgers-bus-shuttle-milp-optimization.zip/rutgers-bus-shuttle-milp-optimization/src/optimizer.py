from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp


@dataclass(frozen=True)
class Route:
    name: str
    passenger_demand: float
    travel_time_hours: float
    coverage: dict[str, int]


@dataclass(frozen=True)
class OptimizationSolution:
    success: bool
    status: str
    objective_value: float
    passenger_time_component: float
    bus_cost_component: float
    route_activation: dict[str, int]
    bus_allocation: dict[str, int]
    stop_coverage: dict[str, int]

    @property
    def selected_routes(self) -> list[str]:
        return [name for name, active in self.route_activation.items() if active == 1]

    @property
    def total_buses(self) -> int:
        return sum(self.bus_allocation.values())


def load_routes(csv_path: str | Path) -> list[Route]:
    """Load route demand, travel time, and stop-incidence data from CSV."""
    path = Path(csv_path)
    with path.open(newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        required = {"route", "passenger_demand", "travel_time_hours"}
        if not reader.fieldnames or not required.issubset(reader.fieldnames):
            raise ValueError(f"{path} is missing one or more required columns: {sorted(required)}")

        stop_columns = [c for c in reader.fieldnames if c not in required]
        routes: list[Route] = []
        for row in reader:
            coverage = {stop: int(float(row[stop])) for stop in stop_columns}
            routes.append(
                Route(
                    name=row["route"].strip(),
                    passenger_demand=float(row["passenger_demand"]),
                    travel_time_hours=float(row["travel_time_hours"]),
                    coverage=coverage,
                )
            )
    if not routes:
        raise ValueError(f"No routes found in {path}")
    return routes


def solve_bus_network(
    routes: list[Route],
    required_stops: Iterable[str],
    bus_cost_weight: float = 500.0,
    max_buses_per_route: int = 10,
) -> OptimizationSolution:
    """Solve the route-selection and fleet-linking MILP using SciPy/HiGHS.

    Variables are ordered as [y_1,...,y_R,x_1,...,x_R], where y is binary
    route activation and x is the integer number of buses assigned to a route.
    """
    if bus_cost_weight < 0:
        raise ValueError("bus_cost_weight must be nonnegative")
    if max_buses_per_route < 1:
        raise ValueError("max_buses_per_route must be at least 1")

    stops = list(required_stops)
    if not stops:
        raise ValueError("At least one required stop is needed")

    missing = [stop for stop in stops if any(stop not in route.coverage for route in routes)]
    if missing:
        raise ValueError(f"Coverage data is missing required stops: {sorted(set(missing))}")

    n_routes = len(routes)
    n_stops = len(stops)

    passenger_coefficients = np.array(
        [r.passenger_demand * r.travel_time_hours for r in routes], dtype=float
    )
    objective = np.concatenate(
        [passenger_coefficients, np.full(n_routes, float(bus_cost_weight))]
    )

    coverage_matrix = np.array(
        [[route.coverage[stop] for route in routes] for stop in stops], dtype=float
    )

    # Every required stop must be covered by at least one active route.
    coverage_constraint = LinearConstraint(
        np.column_stack([coverage_matrix, np.zeros((n_stops, n_routes))]),
        lb=np.ones(n_stops),
        ub=np.full(n_stops, np.inf),
    )

    identity = np.eye(n_routes)

    # x_r >= y_r: an active route receives at least one bus.
    minimum_bus_constraint = LinearConstraint(
        np.column_stack([-identity, identity]),
        lb=np.zeros(n_routes),
        ub=np.full(n_routes, np.inf),
    )

    # x_r <= M y_r: an inactive route cannot receive buses.
    maximum_bus_constraint = LinearConstraint(
        np.column_stack([-max_buses_per_route * identity, identity]),
        lb=np.full(n_routes, -np.inf),
        ub=np.zeros(n_routes),
    )

    lower_bounds = np.zeros(2 * n_routes)
    upper_bounds = np.concatenate(
        [np.ones(n_routes), np.full(n_routes, max_buses_per_route)]
    )

    result = milp(
        c=objective,
        integrality=np.ones(2 * n_routes, dtype=int),
        bounds=Bounds(lower_bounds, upper_bounds),
        constraints=[coverage_constraint, minimum_bus_constraint, maximum_bus_constraint],
        options={"disp": False},
    )

    if not result.success or result.x is None:
        return OptimizationSolution(
            success=False,
            status=result.message,
            objective_value=float("nan"),
            passenger_time_component=float("nan"),
            bus_cost_component=float("nan"),
            route_activation={},
            bus_allocation={},
            stop_coverage={},
        )

    y = np.rint(result.x[:n_routes]).astype(int)
    x = np.rint(result.x[n_routes:]).astype(int)
    route_names = [route.name for route in routes]

    route_activation = dict(zip(route_names, y.tolist()))
    bus_allocation = dict(zip(route_names, x.tolist()))
    stop_coverage_values = coverage_matrix @ y
    stop_coverage = dict(zip(stops, np.rint(stop_coverage_values).astype(int).tolist()))

    passenger_component = float(passenger_coefficients @ y)
    bus_component = float(bus_cost_weight * x.sum())

    return OptimizationSolution(
        success=True,
        status=result.message,
        objective_value=passenger_component + bus_component,
        passenger_time_component=passenger_component,
        bus_cost_component=bus_component,
        route_activation=route_activation,
        bus_allocation=bus_allocation,
        stop_coverage=stop_coverage,
    )
