# Publish This Repository on GitHub

## Easiest method: GitHub Desktop

1. Download and unzip `rutgers-bus-shuttle-milp-optimization.zip`.
2. Open **GitHub Desktop**.
3. Select **File → Add local repository**.
4. Choose the unzipped project folder.
5. Click **Publish repository**.
6. Use the repository name `rutgers-bus-shuttle-milp-optimization`.
7. Add this description:

   `MILP-based Rutgers bus route selection and fleet allocation model developed in Excel Solver and reproduced in Python.`

8. Choose whether the repository should be public or private, then click **Publish Repository**.

## Command-line method

```bash
git remote add origin https://github.com/YOUR-USERNAME/rutgers-bus-shuttle-milp-optimization.git
git branch -M main
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username after creating an empty repository on GitHub.
