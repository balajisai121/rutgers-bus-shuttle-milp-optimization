# Project Presentation Summary

## Problem

Rutgers–New Brunswick operates multiple weekday and weekend shuttle routes across a large campus network. The planning challenge is to provide required stop coverage while avoiding unnecessary route activation and fleet use.

## Approach

The project uses a Mixed-Integer Linear Programming model with:

- binary route-selection variables;
- integer bus-allocation variables;
- stop-route incidence data;
- minimum stop-coverage constraints;
- route-to-bus linking constraints; and
- a weighted objective combining passenger travel-time contribution and bus cost.

## Excel implementation

The original model was implemented with Excel Solver. Route demand, travel time, route activation, bus counts, and stop coverage are organized in separate table columns. Solver minimizes the objective cell subject to binary, integer, route-linking, and stop-coverage constraints.

## Results

- Weekday: operate EE, F, H, and LX with one bus per route.
- Weekend: operate Weekend 1 with one bus.
- All required stops in the configured model are covered.

## Interpretation

The model is useful as a transparent route-selection baseline. Its next development step is to represent how frequency affects waiting time and crowding.
