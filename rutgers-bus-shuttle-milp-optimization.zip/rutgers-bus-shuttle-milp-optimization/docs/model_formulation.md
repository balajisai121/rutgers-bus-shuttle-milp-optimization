# Mathematical Formulation

## 1. Sets

- `R`: candidate bus routes.
- `S`: stops that must be covered.

The weekday model contains ten candidate routes and nineteen required stops. The weekend workbook applies coverage constraints to CASC, BSC, LSC, CDC, and SAC.

## 2. Parameters

- `P_r`: passenger demand associated with route `r`.
- `T_r`: route travel time for route `r`.
- `a_rs`: 1 if route `r` serves stop `s`; 0 otherwise.
- `c`: cost weight for one assigned bus. The base model uses `c = 500`.
- `M`: maximum buses permitted on one route. The base model uses `M = 10`.

## 3. Decision variables

- `y_r ∈ {0,1}`: route activation variable.
- `x_r ∈ Z_+`: number of buses assigned to the route.

## 4. Objective function

The model minimizes the combined passenger-time and fleet-cost terms:

```text
minimize  Σ(P_r T_r y_r) + c Σx_r
           r∈R             r∈R
```

This is a weighted multi-objective formulation. The coefficient `c` converts the fleet-size preference into the same artificial objective scale as the passenger-time term.

## 5. Stop-coverage constraints

Every required stop must be served by at least one selected route:

```text
Σ a_rs y_r >= 1       for every s ∈ S
r∈R
```

## 6. Route–bus linking constraints

An active route receives at least one bus:

```text
x_r >= y_r            for every r ∈ R
```

An inactive route receives no buses, while an active route may receive at most `M` buses:

```text
x_r <= M y_r          for every r ∈ R
```

## 7. Variable domains

```text
y_r ∈ {0,1}
x_r ∈ {0,1,...,M}
```

## 8. Why this is an MILP

The objective and constraints are linear, while the model contains binary and integer decision variables. It is therefore a Mixed-Integer Linear Program. Structurally, it combines a set-covering route-selection problem with fleet-allocation linking constraints.
