# Model Validation and Limitations

## Validation against Excel Solver

The Python model was checked against the Solver answer reports in the original workbook.

| Measure | Excel weekday | Python weekday | Excel weekend | Python weekend |
|---|---:|---:|---:|---:|
| Passenger-time component | 170 | 170 | 64 | 64 |
| Bus-cost component | 2,000 | 2,000 | 500 | 500 |
| Total objective | 2,170 | 2,170 | 564 | 564 |
| Total buses | 4 | 4 | 1 | 1 |

Selected weekday routes: **EE, F, H, and LX**.  
Selected weekend route: **Weekend 1**.

The automated tests also verify that every required stop has coverage of at least one.

## What the current model does well

- Selects a minimum-cost combination of routes that satisfies stop coverage.
- Uses binary and integer variables correctly.
- Explicitly links route activation and bus assignment.
- Is transparent and easy to reproduce in Excel and Python.

## Main limitation

The passenger-time term is `P_r × T_r × y_r`. It depends on whether a route is active, not on how many buses are assigned. Consequently, assigning a second bus cannot reduce passenger waiting time in the current objective; it can only increase cost. The optimal fleet allocation is therefore one bus per active route.

This means the current formulation should be described as a **route-selection and fleet-linking model**, not yet as a complete service-frequency optimization model.

## Recommended next version

A more realistic frequency model could add:

1. route cycle time and service frequency;
2. expected waiting time, often approximated as half the headway;
3. bus-capacity constraints;
4. route-specific operating costs;
5. a fixed total-fleet constraint;
6. time-period demand, such as morning peak, afternoon peak, and evening;
7. piecewise-linear variables to preserve an MILP formulation while approximating the inverse relation between buses and waiting time.

These additions would allow extra buses to create a measurable service benefit rather than only an additional cost.
