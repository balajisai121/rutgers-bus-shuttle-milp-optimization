# Generated Results

## Weekday

- Selected routes: EE, F, H, LX
- Total buses: 4
- Passenger-time component: 170
- Bus-cost component: 2000
- Objective: **2170**

## Weekend

- Selected routes: Weekend 1
- Total buses: 1
- Passenger-time component: 64
- Bus-cost component: 500
- Objective: **564**
